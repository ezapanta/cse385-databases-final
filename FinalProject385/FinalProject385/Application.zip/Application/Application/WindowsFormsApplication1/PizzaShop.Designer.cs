﻿namespace WindowsFormsApplication1
{
    partial class frmPizzaShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lbPassword = new System.Windows.Forms.Label();
            this.lbID = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnSubmitEmployees = new System.Windows.Forms.Button();
            this.lbLoginpage2 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.btnEnterName = new System.Windows.Forms.Button();
            this.lbLName = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.txtCusomterLName = new System.Windows.Forms.TextBox();
            this.txtCustomerFName = new System.Windows.Forms.TextBox();
            this.lbCustomerName = new System.Windows.Forms.Label();
            this.pnlSausage = new System.Windows.Forms.Panel();
            this.rdbAddSasuage = new System.Windows.Forms.RadioButton();
            this.rdbNoSausage = new System.Windows.Forms.RadioButton();
            this.lbSausage = new System.Windows.Forms.Label();
            this.pnlJalapenos = new System.Windows.Forms.Panel();
            this.rdbAddJalapenos = new System.Windows.Forms.RadioButton();
            this.rdbNoJalapenos = new System.Windows.Forms.RadioButton();
            this.lbJalapenos = new System.Windows.Forms.Label();
            this.pnlGreenPeppers = new System.Windows.Forms.Panel();
            this.rdbAddGreenPeppers = new System.Windows.Forms.RadioButton();
            this.rdbNoGP = new System.Windows.Forms.RadioButton();
            this.lbGreenPeppers = new System.Windows.Forms.Label();
            this.lbToppings = new System.Windows.Forms.Label();
            this.pnlBacon = new System.Windows.Forms.Panel();
            this.rdbAddBacon = new System.Windows.Forms.RadioButton();
            this.rdbNoBacon = new System.Windows.Forms.RadioButton();
            this.lbBacon = new System.Windows.Forms.Label();
            this.pnlBP = new System.Windows.Forms.Panel();
            this.rdbAddBanana = new System.Windows.Forms.RadioButton();
            this.rdbNoBP = new System.Windows.Forms.RadioButton();
            this.lbBananaPeppers = new System.Windows.Forms.Label();
            this.pnlPepperoni = new System.Windows.Forms.Panel();
            this.rdbAddPepperoni = new System.Windows.Forms.RadioButton();
            this.rdbNopepperoni = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.pnlPineapple = new System.Windows.Forms.Panel();
            this.rdbAddPineapple = new System.Windows.Forms.RadioButton();
            this.rdbNoPineapple = new System.Windows.Forms.RadioButton();
            this.lbPineapple = new System.Windows.Forms.Label();
            this.pnlTomato = new System.Windows.Forms.Panel();
            this.rdbAddTomato = new System.Windows.Forms.RadioButton();
            this.rdbNoTomato = new System.Windows.Forms.RadioButton();
            this.lbTomato = new System.Windows.Forms.Label();
            this.pnlHam = new System.Windows.Forms.Panel();
            this.rdbAddHam = new System.Windows.Forms.RadioButton();
            this.rdbNoHam = new System.Windows.Forms.RadioButton();
            this.lbHam = new System.Windows.Forms.Label();
            this.pnlMushrooms = new System.Windows.Forms.Panel();
            this.rdbAddMushrooms = new System.Windows.Forms.RadioButton();
            this.rdbNoMush = new System.Windows.Forms.RadioButton();
            this.lbMushrooms = new System.Windows.Forms.Label();
            this.pnlSpinach = new System.Windows.Forms.Panel();
            this.rdbAddSpinach = new System.Windows.Forms.RadioButton();
            this.rdbNoSpinach = new System.Windows.Forms.RadioButton();
            this.lbSpinach = new System.Windows.Forms.Label();
            this.pnlOnions = new System.Windows.Forms.Panel();
            this.rdbAddOnions = new System.Windows.Forms.RadioButton();
            this.rdbNoOnions = new System.Windows.Forms.RadioButton();
            this.lbOnions = new System.Windows.Forms.Label();
            this.pnlBlackOlives = new System.Windows.Forms.Panel();
            this.rdbAddBlackOlives = new System.Windows.Forms.RadioButton();
            this.rdbNoBO = new System.Windows.Forms.RadioButton();
            this.lbBlackOlives = new System.Windows.Forms.Label();
            this.pnlGreenOlives = new System.Windows.Forms.Panel();
            this.rdbAddGreenOlives = new System.Windows.Forms.RadioButton();
            this.rdbNoGO = new System.Windows.Forms.RadioButton();
            this.lbGreenOlives = new System.Windows.Forms.Label();
            this.pnlAnchovies = new System.Windows.Forms.Panel();
            this.rdbAddAnchovies = new System.Windows.Forms.RadioButton();
            this.rdbNoAnchovies = new System.Windows.Forms.RadioButton();
            this.lbAnchovies = new System.Windows.Forms.Label();
            this.pnlSize = new System.Windows.Forms.Panel();
            this.lbSize = new System.Windows.Forms.Label();
            this.rdbLg = new System.Windows.Forms.RadioButton();
            this.rdbMd = new System.Windows.Forms.RadioButton();
            this.rdbSm = new System.Windows.Forms.RadioButton();
            this.btnAddPizza = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnScrap = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.txtCreditCard = new System.Windows.Forms.TextBox();
            this.lbCreditCard = new System.Windows.Forms.Label();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.btnRemovePizza = new System.Windows.Forms.Button();
            this.lstPizzas = new System.Windows.Forms.ListBox();
            this.lbReview = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.OrderCancelled = new System.Windows.Forms.Button();
            this.btnOrderPaid = new System.Windows.Forms.Button();
            this.lstOrders = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.pnlSausage.SuspendLayout();
            this.pnlJalapenos.SuspendLayout();
            this.pnlGreenPeppers.SuspendLayout();
            this.pnlBacon.SuspendLayout();
            this.pnlBP.SuspendLayout();
            this.pnlPepperoni.SuspendLayout();
            this.pnlPineapple.SuspendLayout();
            this.pnlTomato.SuspendLayout();
            this.pnlHam.SuspendLayout();
            this.pnlMushrooms.SuspendLayout();
            this.pnlSpinach.SuspendLayout();
            this.pnlOnions.SuspendLayout();
            this.pnlBlackOlives.SuspendLayout();
            this.pnlGreenOlives.SuspendLayout();
            this.pnlAnchovies.SuspendLayout();
            this.pnlSize.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(760, 537);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(752, 511);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Home Page";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Location = new System.Drawing.Point(6, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(740, 499);
            this.tabControl2.TabIndex = 11;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnLogout);
            this.tabPage4.Controls.Add(this.lbPassword);
            this.tabPage4.Controls.Add(this.lbID);
            this.tabPage4.Controls.Add(this.txtPassword);
            this.tabPage4.Controls.Add(this.btnSettings);
            this.tabPage4.Controls.Add(this.btnSubmitEmployees);
            this.tabPage4.Controls.Add(this.lbLoginpage2);
            this.tabPage4.Controls.Add(this.txtUserName);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(732, 473);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Login";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnLogout
            // 
            this.btnLogout.Enabled = false;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(72, 336);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnLogout.Size = new System.Drawing.Size(215, 79);
            this.btnLogout.TabIndex = 23;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPassword.Location = new System.Drawing.Point(205, 215);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(78, 20);
            this.lbPassword.TabIndex = 22;
            this.lbPassword.Text = "Password";
            // 
            // lbID
            // 
            this.lbID.AutoSize = true;
            this.lbID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbID.Location = new System.Drawing.Point(194, 153);
            this.lbID.Name = "lbID";
            this.lbID.Size = new System.Drawing.Size(89, 20);
            this.lbID.TabIndex = 21;
            this.lbID.Text = "User Name";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(289, 215);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(195, 20);
            this.txtPassword.TabIndex = 20;
            this.txtPassword.Text = "PizzaLove";
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // btnSettings
            // 
            this.btnSettings.Enabled = false;
            this.btnSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.Location = new System.Drawing.Point(453, 336);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnSettings.Size = new System.Drawing.Size(214, 79);
            this.btnSettings.TabIndex = 19;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // btnSubmitEmployees
            // 
            this.btnSubmitEmployees.Location = new System.Drawing.Point(490, 216);
            this.btnSubmitEmployees.Name = "btnSubmitEmployees";
            this.btnSubmitEmployees.Size = new System.Drawing.Size(44, 20);
            this.btnSubmitEmployees.TabIndex = 18;
            this.btnSubmitEmployees.Text = "->";
            this.btnSubmitEmployees.UseVisualStyleBackColor = true;
            this.btnSubmitEmployees.Click += new System.EventHandler(this.btnSubmitEmployees_Click);
            // 
            // lbLoginpage2
            // 
            this.lbLoginpage2.AutoSize = true;
            this.lbLoginpage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLoginpage2.Location = new System.Drawing.Point(150, 100);
            this.lbLoginpage2.Name = "lbLoginpage2";
            this.lbLoginpage2.Size = new System.Drawing.Size(431, 37);
            this.lbLoginpage2.TabIndex = 16;
            this.lbLoginpage2.Text = "Enter your Login Credentials ";
            this.lbLoginpage2.Click += new System.EventHandler(this.lbLoginpage2_Click);
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(289, 155);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(195, 20);
            this.txtUserName.TabIndex = 12;
            this.txtUserName.Text = "PizzaAdmin";
            this.txtUserName.TextChanged += new System.EventHandler(this.txtEmployeeID_TextChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.lblTotalCost);
            this.tabPage5.Controls.Add(this.btnEnterName);
            this.tabPage5.Controls.Add(this.lbLName);
            this.tabPage5.Controls.Add(this.lblFName);
            this.tabPage5.Controls.Add(this.txtCusomterLName);
            this.tabPage5.Controls.Add(this.txtCustomerFName);
            this.tabPage5.Controls.Add(this.lbCustomerName);
            this.tabPage5.Controls.Add(this.pnlSausage);
            this.tabPage5.Controls.Add(this.pnlJalapenos);
            this.tabPage5.Controls.Add(this.pnlGreenPeppers);
            this.tabPage5.Controls.Add(this.lbToppings);
            this.tabPage5.Controls.Add(this.pnlBacon);
            this.tabPage5.Controls.Add(this.pnlBP);
            this.tabPage5.Controls.Add(this.pnlPepperoni);
            this.tabPage5.Controls.Add(this.pnlPineapple);
            this.tabPage5.Controls.Add(this.pnlTomato);
            this.tabPage5.Controls.Add(this.pnlHam);
            this.tabPage5.Controls.Add(this.pnlMushrooms);
            this.tabPage5.Controls.Add(this.pnlSpinach);
            this.tabPage5.Controls.Add(this.pnlOnions);
            this.tabPage5.Controls.Add(this.pnlBlackOlives);
            this.tabPage5.Controls.Add(this.pnlGreenOlives);
            this.tabPage5.Controls.Add(this.pnlAnchovies);
            this.tabPage5.Controls.Add(this.pnlSize);
            this.tabPage5.Controls.Add(this.btnAddPizza);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(732, 473);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "Create a Pizza";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 422);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 20);
            this.label1.TabIndex = 33;
            this.label1.Text = "Current Cost of Pizza: ";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCost.Location = new System.Drawing.Point(212, 422);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(49, 20);
            this.lblTotalCost.TabIndex = 32;
            this.lblTotalCost.Text = "$0.00";
            this.lblTotalCost.Click += new System.EventHandler(this.lblTotalCost_Click);
            // 
            // btnEnterName
            // 
            this.btnEnterName.Enabled = false;
            this.btnEnterName.Location = new System.Drawing.Point(288, 90);
            this.btnEnterName.Name = "btnEnterName";
            this.btnEnterName.Size = new System.Drawing.Size(44, 20);
            this.btnEnterName.TabIndex = 30;
            this.btnEnterName.Text = "->";
            this.btnEnterName.UseVisualStyleBackColor = true;
            this.btnEnterName.Click += new System.EventHandler(this.btnEnterName_Click);
            // 
            // lbLName
            // 
            this.lbLName.AutoSize = true;
            this.lbLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLName.Location = new System.Drawing.Point(11, 88);
            this.lbLName.Name = "lbLName";
            this.lbLName.Size = new System.Drawing.Size(90, 20);
            this.lbLName.TabIndex = 29;
            this.lbLName.Text = "Last Name:";
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFName.Location = new System.Drawing.Point(11, 52);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(90, 20);
            this.lblFName.TabIndex = 28;
            this.lblFName.Text = "First Name:";
            // 
            // txtCusomterLName
            // 
            this.txtCusomterLName.Location = new System.Drawing.Point(126, 90);
            this.txtCusomterLName.Name = "txtCusomterLName";
            this.txtCusomterLName.Size = new System.Drawing.Size(144, 20);
            this.txtCusomterLName.TabIndex = 27;
            // 
            // txtCustomerFName
            // 
            this.txtCustomerFName.Location = new System.Drawing.Point(126, 54);
            this.txtCustomerFName.Name = "txtCustomerFName";
            this.txtCustomerFName.Size = new System.Drawing.Size(144, 20);
            this.txtCustomerFName.TabIndex = 26;
            // 
            // lbCustomerName
            // 
            this.lbCustomerName.AutoSize = true;
            this.lbCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCustomerName.Location = new System.Drawing.Point(45, 17);
            this.lbCustomerName.Name = "lbCustomerName";
            this.lbCustomerName.Size = new System.Drawing.Size(246, 24);
            this.lbCustomerName.TabIndex = 25;
            this.lbCustomerName.Text = "Enter the Customer\'s Name:";
            // 
            // pnlSausage
            // 
            this.pnlSausage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSausage.Controls.Add(this.rdbAddSasuage);
            this.pnlSausage.Controls.Add(this.rdbNoSausage);
            this.pnlSausage.Controls.Add(this.lbSausage);
            this.pnlSausage.Enabled = false;
            this.pnlSausage.Location = new System.Drawing.Point(42, 194);
            this.pnlSausage.Name = "pnlSausage";
            this.pnlSausage.Size = new System.Drawing.Size(318, 28);
            this.pnlSausage.TabIndex = 19;
            // 
            // rdbAddSasuage
            // 
            this.rdbAddSasuage.AutoSize = true;
            this.rdbAddSasuage.Location = new System.Drawing.Point(130, 5);
            this.rdbAddSasuage.Name = "rdbAddSasuage";
            this.rdbAddSasuage.Size = new System.Drawing.Size(88, 17);
            this.rdbAddSasuage.TabIndex = 2;
            this.rdbAddSasuage.Text = "Add To Pizza";
            this.rdbAddSasuage.UseVisualStyleBackColor = true;
            this.rdbAddSasuage.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoSausage
            // 
            this.rdbNoSausage.AutoSize = true;
            this.rdbNoSausage.Checked = true;
            this.rdbNoSausage.Location = new System.Drawing.Point(224, 5);
            this.rdbNoSausage.Name = "rdbNoSausage";
            this.rdbNoSausage.Size = new System.Drawing.Size(85, 17);
            this.rdbNoSausage.TabIndex = 1;
            this.rdbNoSausage.TabStop = true;
            this.rdbNoSausage.Text = "Not on Pizza";
            this.rdbNoSausage.UseVisualStyleBackColor = true;
            // 
            // lbSausage
            // 
            this.lbSausage.AutoSize = true;
            this.lbSausage.Location = new System.Drawing.Point(3, 7);
            this.lbSausage.Name = "lbSausage";
            this.lbSausage.Size = new System.Drawing.Size(49, 13);
            this.lbSausage.TabIndex = 0;
            this.lbSausage.Text = "Sausage";
            // 
            // pnlJalapenos
            // 
            this.pnlJalapenos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlJalapenos.Controls.Add(this.rdbAddJalapenos);
            this.pnlJalapenos.Controls.Add(this.rdbNoJalapenos);
            this.pnlJalapenos.Controls.Add(this.lbJalapenos);
            this.pnlJalapenos.Enabled = false;
            this.pnlJalapenos.Location = new System.Drawing.Point(376, 364);
            this.pnlJalapenos.Name = "pnlJalapenos";
            this.pnlJalapenos.Size = new System.Drawing.Size(318, 28);
            this.pnlJalapenos.TabIndex = 22;
            // 
            // rdbAddJalapenos
            // 
            this.rdbAddJalapenos.AutoSize = true;
            this.rdbAddJalapenos.Location = new System.Drawing.Point(130, 5);
            this.rdbAddJalapenos.Name = "rdbAddJalapenos";
            this.rdbAddJalapenos.Size = new System.Drawing.Size(88, 17);
            this.rdbAddJalapenos.TabIndex = 2;
            this.rdbAddJalapenos.Text = "Add To Pizza";
            this.rdbAddJalapenos.UseVisualStyleBackColor = true;
            this.rdbAddJalapenos.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoJalapenos
            // 
            this.rdbNoJalapenos.AutoSize = true;
            this.rdbNoJalapenos.Checked = true;
            this.rdbNoJalapenos.Location = new System.Drawing.Point(224, 5);
            this.rdbNoJalapenos.Name = "rdbNoJalapenos";
            this.rdbNoJalapenos.Size = new System.Drawing.Size(85, 17);
            this.rdbNoJalapenos.TabIndex = 1;
            this.rdbNoJalapenos.TabStop = true;
            this.rdbNoJalapenos.Text = "Not on Pizza";
            this.rdbNoJalapenos.UseVisualStyleBackColor = true;
            // 
            // lbJalapenos
            // 
            this.lbJalapenos.AutoSize = true;
            this.lbJalapenos.Location = new System.Drawing.Point(3, 7);
            this.lbJalapenos.Name = "lbJalapenos";
            this.lbJalapenos.Size = new System.Drawing.Size(55, 13);
            this.lbJalapenos.TabIndex = 0;
            this.lbJalapenos.Text = "Jalapenos";
            // 
            // pnlGreenPeppers
            // 
            this.pnlGreenPeppers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGreenPeppers.Controls.Add(this.rdbAddGreenPeppers);
            this.pnlGreenPeppers.Controls.Add(this.rdbNoGP);
            this.pnlGreenPeppers.Controls.Add(this.lbGreenPeppers);
            this.pnlGreenPeppers.Enabled = false;
            this.pnlGreenPeppers.Location = new System.Drawing.Point(42, 330);
            this.pnlGreenPeppers.Name = "pnlGreenPeppers";
            this.pnlGreenPeppers.Size = new System.Drawing.Size(318, 28);
            this.pnlGreenPeppers.TabIndex = 12;
            // 
            // rdbAddGreenPeppers
            // 
            this.rdbAddGreenPeppers.AutoSize = true;
            this.rdbAddGreenPeppers.Location = new System.Drawing.Point(130, 5);
            this.rdbAddGreenPeppers.Name = "rdbAddGreenPeppers";
            this.rdbAddGreenPeppers.Size = new System.Drawing.Size(88, 17);
            this.rdbAddGreenPeppers.TabIndex = 2;
            this.rdbAddGreenPeppers.Text = "Add To Pizza";
            this.rdbAddGreenPeppers.UseVisualStyleBackColor = true;
            this.rdbAddGreenPeppers.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoGP
            // 
            this.rdbNoGP.AutoSize = true;
            this.rdbNoGP.Checked = true;
            this.rdbNoGP.Location = new System.Drawing.Point(224, 5);
            this.rdbNoGP.Name = "rdbNoGP";
            this.rdbNoGP.Size = new System.Drawing.Size(85, 17);
            this.rdbNoGP.TabIndex = 1;
            this.rdbNoGP.TabStop = true;
            this.rdbNoGP.Text = "Not on Pizza";
            this.rdbNoGP.UseVisualStyleBackColor = true;
            // 
            // lbGreenPeppers
            // 
            this.lbGreenPeppers.AutoSize = true;
            this.lbGreenPeppers.Location = new System.Drawing.Point(3, 7);
            this.lbGreenPeppers.Name = "lbGreenPeppers";
            this.lbGreenPeppers.Size = new System.Drawing.Size(78, 13);
            this.lbGreenPeppers.TabIndex = 0;
            this.lbGreenPeppers.Text = "Green Peppers";
            // 
            // lbToppings
            // 
            this.lbToppings.AutoSize = true;
            this.lbToppings.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbToppings.Location = new System.Drawing.Point(116, 124);
            this.lbToppings.Name = "lbToppings";
            this.lbToppings.Size = new System.Drawing.Size(166, 24);
            this.lbToppings.TabIndex = 6;
            this.lbToppings.Text = "Choose Toppings:";
            // 
            // pnlBacon
            // 
            this.pnlBacon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBacon.Controls.Add(this.rdbAddBacon);
            this.pnlBacon.Controls.Add(this.rdbNoBacon);
            this.pnlBacon.Controls.Add(this.lbBacon);
            this.pnlBacon.Enabled = false;
            this.pnlBacon.Location = new System.Drawing.Point(42, 228);
            this.pnlBacon.Name = "pnlBacon";
            this.pnlBacon.Size = new System.Drawing.Size(318, 28);
            this.pnlBacon.TabIndex = 22;
            // 
            // rdbAddBacon
            // 
            this.rdbAddBacon.AutoSize = true;
            this.rdbAddBacon.Location = new System.Drawing.Point(130, 5);
            this.rdbAddBacon.Name = "rdbAddBacon";
            this.rdbAddBacon.Size = new System.Drawing.Size(88, 17);
            this.rdbAddBacon.TabIndex = 2;
            this.rdbAddBacon.Text = "Add To Pizza";
            this.rdbAddBacon.UseVisualStyleBackColor = true;
            this.rdbAddBacon.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoBacon
            // 
            this.rdbNoBacon.AutoSize = true;
            this.rdbNoBacon.Checked = true;
            this.rdbNoBacon.Location = new System.Drawing.Point(224, 5);
            this.rdbNoBacon.Name = "rdbNoBacon";
            this.rdbNoBacon.Size = new System.Drawing.Size(85, 17);
            this.rdbNoBacon.TabIndex = 1;
            this.rdbNoBacon.TabStop = true;
            this.rdbNoBacon.Text = "Not on Pizza";
            this.rdbNoBacon.UseVisualStyleBackColor = true;
            // 
            // lbBacon
            // 
            this.lbBacon.AutoSize = true;
            this.lbBacon.Location = new System.Drawing.Point(3, 7);
            this.lbBacon.Name = "lbBacon";
            this.lbBacon.Size = new System.Drawing.Size(38, 13);
            this.lbBacon.TabIndex = 0;
            this.lbBacon.Text = "Bacon";
            // 
            // pnlBP
            // 
            this.pnlBP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBP.Controls.Add(this.rdbAddBanana);
            this.pnlBP.Controls.Add(this.rdbNoBP);
            this.pnlBP.Controls.Add(this.lbBananaPeppers);
            this.pnlBP.Enabled = false;
            this.pnlBP.Location = new System.Drawing.Point(376, 330);
            this.pnlBP.Name = "pnlBP";
            this.pnlBP.Size = new System.Drawing.Size(318, 28);
            this.pnlBP.TabIndex = 21;
            // 
            // rdbAddBanana
            // 
            this.rdbAddBanana.AutoSize = true;
            this.rdbAddBanana.Location = new System.Drawing.Point(130, 5);
            this.rdbAddBanana.Name = "rdbAddBanana";
            this.rdbAddBanana.Size = new System.Drawing.Size(88, 17);
            this.rdbAddBanana.TabIndex = 2;
            this.rdbAddBanana.Text = "Add To Pizza";
            this.rdbAddBanana.UseVisualStyleBackColor = true;
            this.rdbAddBanana.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoBP
            // 
            this.rdbNoBP.AutoSize = true;
            this.rdbNoBP.Checked = true;
            this.rdbNoBP.Location = new System.Drawing.Point(224, 5);
            this.rdbNoBP.Name = "rdbNoBP";
            this.rdbNoBP.Size = new System.Drawing.Size(85, 17);
            this.rdbNoBP.TabIndex = 1;
            this.rdbNoBP.TabStop = true;
            this.rdbNoBP.Text = "Not on Pizza";
            this.rdbNoBP.UseVisualStyleBackColor = true;
            // 
            // lbBananaPeppers
            // 
            this.lbBananaPeppers.AutoSize = true;
            this.lbBananaPeppers.Location = new System.Drawing.Point(3, 7);
            this.lbBananaPeppers.Name = "lbBananaPeppers";
            this.lbBananaPeppers.Size = new System.Drawing.Size(86, 13);
            this.lbBananaPeppers.TabIndex = 0;
            this.lbBananaPeppers.Text = "Banana Peppers";
            // 
            // pnlPepperoni
            // 
            this.pnlPepperoni.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPepperoni.Controls.Add(this.rdbAddPepperoni);
            this.pnlPepperoni.Controls.Add(this.rdbNopepperoni);
            this.pnlPepperoni.Controls.Add(this.label15);
            this.pnlPepperoni.Enabled = false;
            this.pnlPepperoni.Location = new System.Drawing.Point(42, 160);
            this.pnlPepperoni.Name = "pnlPepperoni";
            this.pnlPepperoni.Size = new System.Drawing.Size(318, 28);
            this.pnlPepperoni.TabIndex = 18;
            // 
            // rdbAddPepperoni
            // 
            this.rdbAddPepperoni.AutoSize = true;
            this.rdbAddPepperoni.Location = new System.Drawing.Point(130, 5);
            this.rdbAddPepperoni.Name = "rdbAddPepperoni";
            this.rdbAddPepperoni.Size = new System.Drawing.Size(88, 17);
            this.rdbAddPepperoni.TabIndex = 2;
            this.rdbAddPepperoni.Text = "Add To Pizza";
            this.rdbAddPepperoni.UseVisualStyleBackColor = true;
            this.rdbAddPepperoni.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNopepperoni
            // 
            this.rdbNopepperoni.AutoSize = true;
            this.rdbNopepperoni.Checked = true;
            this.rdbNopepperoni.Location = new System.Drawing.Point(224, 5);
            this.rdbNopepperoni.Name = "rdbNopepperoni";
            this.rdbNopepperoni.Size = new System.Drawing.Size(85, 17);
            this.rdbNopepperoni.TabIndex = 1;
            this.rdbNopepperoni.TabStop = true;
            this.rdbNopepperoni.Text = "Not on Pizza";
            this.rdbNopepperoni.UseVisualStyleBackColor = true;
            this.rdbNopepperoni.CheckedChanged += new System.EventHandler(this.radioButton28_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 7);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Pepperoni";
            // 
            // pnlPineapple
            // 
            this.pnlPineapple.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPineapple.Controls.Add(this.rdbAddPineapple);
            this.pnlPineapple.Controls.Add(this.rdbNoPineapple);
            this.pnlPineapple.Controls.Add(this.lbPineapple);
            this.pnlPineapple.Enabled = false;
            this.pnlPineapple.Location = new System.Drawing.Point(42, 296);
            this.pnlPineapple.Name = "pnlPineapple";
            this.pnlPineapple.Size = new System.Drawing.Size(318, 28);
            this.pnlPineapple.TabIndex = 20;
            // 
            // rdbAddPineapple
            // 
            this.rdbAddPineapple.AutoSize = true;
            this.rdbAddPineapple.Location = new System.Drawing.Point(130, 5);
            this.rdbAddPineapple.Name = "rdbAddPineapple";
            this.rdbAddPineapple.Size = new System.Drawing.Size(88, 17);
            this.rdbAddPineapple.TabIndex = 2;
            this.rdbAddPineapple.Text = "Add To Pizza";
            this.rdbAddPineapple.UseVisualStyleBackColor = true;
            this.rdbAddPineapple.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoPineapple
            // 
            this.rdbNoPineapple.AutoSize = true;
            this.rdbNoPineapple.Checked = true;
            this.rdbNoPineapple.Location = new System.Drawing.Point(224, 5);
            this.rdbNoPineapple.Name = "rdbNoPineapple";
            this.rdbNoPineapple.Size = new System.Drawing.Size(85, 17);
            this.rdbNoPineapple.TabIndex = 1;
            this.rdbNoPineapple.TabStop = true;
            this.rdbNoPineapple.Text = "Not on Pizza";
            this.rdbNoPineapple.UseVisualStyleBackColor = true;
            // 
            // lbPineapple
            // 
            this.lbPineapple.AutoSize = true;
            this.lbPineapple.Location = new System.Drawing.Point(3, 7);
            this.lbPineapple.Name = "lbPineapple";
            this.lbPineapple.Size = new System.Drawing.Size(54, 13);
            this.lbPineapple.TabIndex = 0;
            this.lbPineapple.Text = "Pineapple";
            // 
            // pnlTomato
            // 
            this.pnlTomato.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTomato.Controls.Add(this.rdbAddTomato);
            this.pnlTomato.Controls.Add(this.rdbNoTomato);
            this.pnlTomato.Controls.Add(this.lbTomato);
            this.pnlTomato.Enabled = false;
            this.pnlTomato.Location = new System.Drawing.Point(376, 296);
            this.pnlTomato.Name = "pnlTomato";
            this.pnlTomato.Size = new System.Drawing.Size(318, 28);
            this.pnlTomato.TabIndex = 20;
            // 
            // rdbAddTomato
            // 
            this.rdbAddTomato.AutoSize = true;
            this.rdbAddTomato.Location = new System.Drawing.Point(130, 5);
            this.rdbAddTomato.Name = "rdbAddTomato";
            this.rdbAddTomato.Size = new System.Drawing.Size(88, 17);
            this.rdbAddTomato.TabIndex = 2;
            this.rdbAddTomato.Text = "Add To Pizza";
            this.rdbAddTomato.UseVisualStyleBackColor = true;
            this.rdbAddTomato.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoTomato
            // 
            this.rdbNoTomato.AutoSize = true;
            this.rdbNoTomato.Checked = true;
            this.rdbNoTomato.Location = new System.Drawing.Point(224, 5);
            this.rdbNoTomato.Name = "rdbNoTomato";
            this.rdbNoTomato.Size = new System.Drawing.Size(85, 17);
            this.rdbNoTomato.TabIndex = 1;
            this.rdbNoTomato.TabStop = true;
            this.rdbNoTomato.Text = "Not on Pizza";
            this.rdbNoTomato.UseVisualStyleBackColor = true;
            // 
            // lbTomato
            // 
            this.lbTomato.AutoSize = true;
            this.lbTomato.Location = new System.Drawing.Point(3, 7);
            this.lbTomato.Name = "lbTomato";
            this.lbTomato.Size = new System.Drawing.Size(43, 13);
            this.lbTomato.TabIndex = 0;
            this.lbTomato.Text = "Tomato";
            // 
            // pnlHam
            // 
            this.pnlHam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHam.Controls.Add(this.rdbAddHam);
            this.pnlHam.Controls.Add(this.rdbNoHam);
            this.pnlHam.Controls.Add(this.lbHam);
            this.pnlHam.Enabled = false;
            this.pnlHam.Location = new System.Drawing.Point(42, 262);
            this.pnlHam.Name = "pnlHam";
            this.pnlHam.Size = new System.Drawing.Size(318, 28);
            this.pnlHam.TabIndex = 21;
            // 
            // rdbAddHam
            // 
            this.rdbAddHam.AutoSize = true;
            this.rdbAddHam.Location = new System.Drawing.Point(130, 5);
            this.rdbAddHam.Name = "rdbAddHam";
            this.rdbAddHam.Size = new System.Drawing.Size(88, 17);
            this.rdbAddHam.TabIndex = 2;
            this.rdbAddHam.Text = "Add To Pizza";
            this.rdbAddHam.UseVisualStyleBackColor = true;
            this.rdbAddHam.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoHam
            // 
            this.rdbNoHam.AutoSize = true;
            this.rdbNoHam.Checked = true;
            this.rdbNoHam.Location = new System.Drawing.Point(224, 5);
            this.rdbNoHam.Name = "rdbNoHam";
            this.rdbNoHam.Size = new System.Drawing.Size(85, 17);
            this.rdbNoHam.TabIndex = 1;
            this.rdbNoHam.TabStop = true;
            this.rdbNoHam.Text = "Not on Pizza";
            this.rdbNoHam.UseVisualStyleBackColor = true;
            // 
            // lbHam
            // 
            this.lbHam.AutoSize = true;
            this.lbHam.Location = new System.Drawing.Point(3, 7);
            this.lbHam.Name = "lbHam";
            this.lbHam.Size = new System.Drawing.Size(29, 13);
            this.lbHam.TabIndex = 0;
            this.lbHam.Text = "Ham";
            // 
            // pnlMushrooms
            // 
            this.pnlMushrooms.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMushrooms.Controls.Add(this.rdbAddMushrooms);
            this.pnlMushrooms.Controls.Add(this.rdbNoMush);
            this.pnlMushrooms.Controls.Add(this.lbMushrooms);
            this.pnlMushrooms.Enabled = false;
            this.pnlMushrooms.Location = new System.Drawing.Point(376, 262);
            this.pnlMushrooms.Name = "pnlMushrooms";
            this.pnlMushrooms.Size = new System.Drawing.Size(318, 28);
            this.pnlMushrooms.TabIndex = 19;
            // 
            // rdbAddMushrooms
            // 
            this.rdbAddMushrooms.AutoSize = true;
            this.rdbAddMushrooms.Location = new System.Drawing.Point(130, 5);
            this.rdbAddMushrooms.Name = "rdbAddMushrooms";
            this.rdbAddMushrooms.Size = new System.Drawing.Size(88, 17);
            this.rdbAddMushrooms.TabIndex = 2;
            this.rdbAddMushrooms.Text = "Add To Pizza";
            this.rdbAddMushrooms.UseVisualStyleBackColor = true;
            this.rdbAddMushrooms.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoMush
            // 
            this.rdbNoMush.AutoSize = true;
            this.rdbNoMush.Checked = true;
            this.rdbNoMush.Location = new System.Drawing.Point(224, 5);
            this.rdbNoMush.Name = "rdbNoMush";
            this.rdbNoMush.Size = new System.Drawing.Size(85, 17);
            this.rdbNoMush.TabIndex = 1;
            this.rdbNoMush.TabStop = true;
            this.rdbNoMush.Text = "Not on Pizza";
            this.rdbNoMush.UseVisualStyleBackColor = true;
            // 
            // lbMushrooms
            // 
            this.lbMushrooms.AutoSize = true;
            this.lbMushrooms.Location = new System.Drawing.Point(3, 7);
            this.lbMushrooms.Name = "lbMushrooms";
            this.lbMushrooms.Size = new System.Drawing.Size(61, 13);
            this.lbMushrooms.TabIndex = 0;
            this.lbMushrooms.Text = "Mushrooms";
            // 
            // pnlSpinach
            // 
            this.pnlSpinach.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSpinach.Controls.Add(this.rdbAddSpinach);
            this.pnlSpinach.Controls.Add(this.rdbNoSpinach);
            this.pnlSpinach.Controls.Add(this.lbSpinach);
            this.pnlSpinach.Enabled = false;
            this.pnlSpinach.Location = new System.Drawing.Point(376, 228);
            this.pnlSpinach.Name = "pnlSpinach";
            this.pnlSpinach.Size = new System.Drawing.Size(318, 28);
            this.pnlSpinach.TabIndex = 18;
            // 
            // rdbAddSpinach
            // 
            this.rdbAddSpinach.AutoSize = true;
            this.rdbAddSpinach.Location = new System.Drawing.Point(130, 5);
            this.rdbAddSpinach.Name = "rdbAddSpinach";
            this.rdbAddSpinach.Size = new System.Drawing.Size(88, 17);
            this.rdbAddSpinach.TabIndex = 2;
            this.rdbAddSpinach.Text = "Add To Pizza";
            this.rdbAddSpinach.UseVisualStyleBackColor = true;
            this.rdbAddSpinach.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoSpinach
            // 
            this.rdbNoSpinach.AutoSize = true;
            this.rdbNoSpinach.Checked = true;
            this.rdbNoSpinach.Location = new System.Drawing.Point(224, 5);
            this.rdbNoSpinach.Name = "rdbNoSpinach";
            this.rdbNoSpinach.Size = new System.Drawing.Size(85, 17);
            this.rdbNoSpinach.TabIndex = 1;
            this.rdbNoSpinach.TabStop = true;
            this.rdbNoSpinach.Text = "Not on Pizza";
            this.rdbNoSpinach.UseVisualStyleBackColor = true;
            // 
            // lbSpinach
            // 
            this.lbSpinach.AutoSize = true;
            this.lbSpinach.Location = new System.Drawing.Point(3, 7);
            this.lbSpinach.Name = "lbSpinach";
            this.lbSpinach.Size = new System.Drawing.Size(46, 13);
            this.lbSpinach.TabIndex = 0;
            this.lbSpinach.Text = "Spinach";
            // 
            // pnlOnions
            // 
            this.pnlOnions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlOnions.Controls.Add(this.rdbAddOnions);
            this.pnlOnions.Controls.Add(this.rdbNoOnions);
            this.pnlOnions.Controls.Add(this.lbOnions);
            this.pnlOnions.Enabled = false;
            this.pnlOnions.Location = new System.Drawing.Point(42, 364);
            this.pnlOnions.Name = "pnlOnions";
            this.pnlOnions.Size = new System.Drawing.Size(318, 28);
            this.pnlOnions.TabIndex = 13;
            // 
            // rdbAddOnions
            // 
            this.rdbAddOnions.AutoSize = true;
            this.rdbAddOnions.Location = new System.Drawing.Point(130, 5);
            this.rdbAddOnions.Name = "rdbAddOnions";
            this.rdbAddOnions.Size = new System.Drawing.Size(88, 17);
            this.rdbAddOnions.TabIndex = 2;
            this.rdbAddOnions.Text = "Add To Pizza";
            this.rdbAddOnions.UseVisualStyleBackColor = true;
            this.rdbAddOnions.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoOnions
            // 
            this.rdbNoOnions.AutoSize = true;
            this.rdbNoOnions.Checked = true;
            this.rdbNoOnions.Location = new System.Drawing.Point(224, 5);
            this.rdbNoOnions.Name = "rdbNoOnions";
            this.rdbNoOnions.Size = new System.Drawing.Size(85, 17);
            this.rdbNoOnions.TabIndex = 1;
            this.rdbNoOnions.TabStop = true;
            this.rdbNoOnions.Text = "Not on Pizza";
            this.rdbNoOnions.UseVisualStyleBackColor = true;
            // 
            // lbOnions
            // 
            this.lbOnions.AutoSize = true;
            this.lbOnions.Location = new System.Drawing.Point(3, 7);
            this.lbOnions.Name = "lbOnions";
            this.lbOnions.Size = new System.Drawing.Size(40, 13);
            this.lbOnions.TabIndex = 0;
            this.lbOnions.Text = "Onions";
            // 
            // pnlBlackOlives
            // 
            this.pnlBlackOlives.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBlackOlives.Controls.Add(this.rdbAddBlackOlives);
            this.pnlBlackOlives.Controls.Add(this.rdbNoBO);
            this.pnlBlackOlives.Controls.Add(this.lbBlackOlives);
            this.pnlBlackOlives.Enabled = false;
            this.pnlBlackOlives.Location = new System.Drawing.Point(376, 126);
            this.pnlBlackOlives.Name = "pnlBlackOlives";
            this.pnlBlackOlives.Size = new System.Drawing.Size(318, 28);
            this.pnlBlackOlives.TabIndex = 17;
            // 
            // rdbAddBlackOlives
            // 
            this.rdbAddBlackOlives.AutoSize = true;
            this.rdbAddBlackOlives.Location = new System.Drawing.Point(130, 5);
            this.rdbAddBlackOlives.Name = "rdbAddBlackOlives";
            this.rdbAddBlackOlives.Size = new System.Drawing.Size(88, 17);
            this.rdbAddBlackOlives.TabIndex = 2;
            this.rdbAddBlackOlives.Text = "Add To Pizza";
            this.rdbAddBlackOlives.UseVisualStyleBackColor = true;
            this.rdbAddBlackOlives.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoBO
            // 
            this.rdbNoBO.AutoSize = true;
            this.rdbNoBO.Checked = true;
            this.rdbNoBO.Location = new System.Drawing.Point(224, 5);
            this.rdbNoBO.Name = "rdbNoBO";
            this.rdbNoBO.Size = new System.Drawing.Size(85, 17);
            this.rdbNoBO.TabIndex = 1;
            this.rdbNoBO.TabStop = true;
            this.rdbNoBO.Text = "Not on Pizza";
            this.rdbNoBO.UseVisualStyleBackColor = true;
            // 
            // lbBlackOlives
            // 
            this.lbBlackOlives.AutoSize = true;
            this.lbBlackOlives.Location = new System.Drawing.Point(3, 7);
            this.lbBlackOlives.Name = "lbBlackOlives";
            this.lbBlackOlives.Size = new System.Drawing.Size(66, 13);
            this.lbBlackOlives.TabIndex = 0;
            this.lbBlackOlives.Text = "Black Olives";
            // 
            // pnlGreenOlives
            // 
            this.pnlGreenOlives.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGreenOlives.Controls.Add(this.rdbAddGreenOlives);
            this.pnlGreenOlives.Controls.Add(this.rdbNoGO);
            this.pnlGreenOlives.Controls.Add(this.lbGreenOlives);
            this.pnlGreenOlives.Enabled = false;
            this.pnlGreenOlives.Location = new System.Drawing.Point(376, 160);
            this.pnlGreenOlives.Name = "pnlGreenOlives";
            this.pnlGreenOlives.Size = new System.Drawing.Size(318, 28);
            this.pnlGreenOlives.TabIndex = 16;
            // 
            // rdbAddGreenOlives
            // 
            this.rdbAddGreenOlives.AutoSize = true;
            this.rdbAddGreenOlives.Location = new System.Drawing.Point(130, 5);
            this.rdbAddGreenOlives.Name = "rdbAddGreenOlives";
            this.rdbAddGreenOlives.Size = new System.Drawing.Size(88, 17);
            this.rdbAddGreenOlives.TabIndex = 2;
            this.rdbAddGreenOlives.Text = "Add To Pizza";
            this.rdbAddGreenOlives.UseVisualStyleBackColor = true;
            this.rdbAddGreenOlives.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoGO
            // 
            this.rdbNoGO.AutoSize = true;
            this.rdbNoGO.Checked = true;
            this.rdbNoGO.Location = new System.Drawing.Point(224, 5);
            this.rdbNoGO.Name = "rdbNoGO";
            this.rdbNoGO.Size = new System.Drawing.Size(85, 17);
            this.rdbNoGO.TabIndex = 1;
            this.rdbNoGO.TabStop = true;
            this.rdbNoGO.Text = "Not on Pizza";
            this.rdbNoGO.UseVisualStyleBackColor = true;
            // 
            // lbGreenOlives
            // 
            this.lbGreenOlives.AutoSize = true;
            this.lbGreenOlives.Location = new System.Drawing.Point(3, 7);
            this.lbGreenOlives.Name = "lbGreenOlives";
            this.lbGreenOlives.Size = new System.Drawing.Size(68, 13);
            this.lbGreenOlives.TabIndex = 0;
            this.lbGreenOlives.Text = "Green Olives";
            // 
            // pnlAnchovies
            // 
            this.pnlAnchovies.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAnchovies.Controls.Add(this.rdbAddAnchovies);
            this.pnlAnchovies.Controls.Add(this.rdbNoAnchovies);
            this.pnlAnchovies.Controls.Add(this.lbAnchovies);
            this.pnlAnchovies.Enabled = false;
            this.pnlAnchovies.Location = new System.Drawing.Point(376, 194);
            this.pnlAnchovies.Name = "pnlAnchovies";
            this.pnlAnchovies.Size = new System.Drawing.Size(318, 28);
            this.pnlAnchovies.TabIndex = 15;
            // 
            // rdbAddAnchovies
            // 
            this.rdbAddAnchovies.AutoSize = true;
            this.rdbAddAnchovies.Location = new System.Drawing.Point(130, 5);
            this.rdbAddAnchovies.Name = "rdbAddAnchovies";
            this.rdbAddAnchovies.Size = new System.Drawing.Size(88, 17);
            this.rdbAddAnchovies.TabIndex = 2;
            this.rdbAddAnchovies.Text = "Add To Pizza";
            this.rdbAddAnchovies.UseVisualStyleBackColor = true;
            this.rdbAddAnchovies.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbNoAnchovies
            // 
            this.rdbNoAnchovies.AutoSize = true;
            this.rdbNoAnchovies.Checked = true;
            this.rdbNoAnchovies.Location = new System.Drawing.Point(224, 5);
            this.rdbNoAnchovies.Name = "rdbNoAnchovies";
            this.rdbNoAnchovies.Size = new System.Drawing.Size(85, 17);
            this.rdbNoAnchovies.TabIndex = 1;
            this.rdbNoAnchovies.TabStop = true;
            this.rdbNoAnchovies.Text = "Not on Pizza";
            this.rdbNoAnchovies.UseVisualStyleBackColor = true;
            // 
            // lbAnchovies
            // 
            this.lbAnchovies.AutoSize = true;
            this.lbAnchovies.Location = new System.Drawing.Point(3, 7);
            this.lbAnchovies.Name = "lbAnchovies";
            this.lbAnchovies.Size = new System.Drawing.Size(57, 13);
            this.lbAnchovies.TabIndex = 0;
            this.lbAnchovies.Text = "Anchovies";
            // 
            // pnlSize
            // 
            this.pnlSize.Controls.Add(this.lbSize);
            this.pnlSize.Controls.Add(this.rdbLg);
            this.pnlSize.Controls.Add(this.rdbMd);
            this.pnlSize.Controls.Add(this.rdbSm);
            this.pnlSize.Enabled = false;
            this.pnlSize.Location = new System.Drawing.Point(376, 6);
            this.pnlSize.Name = "pnlSize";
            this.pnlSize.Size = new System.Drawing.Size(318, 124);
            this.pnlSize.TabIndex = 14;
            // 
            // lbSize
            // 
            this.lbSize.AutoSize = true;
            this.lbSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSize.Location = new System.Drawing.Point(82, 11);
            this.lbSize.Name = "lbSize";
            this.lbSize.Size = new System.Drawing.Size(137, 24);
            this.lbSize.TabIndex = 5;
            this.lbSize.Text = "Choose a Size:";
            this.lbSize.Click += new System.EventHandler(this.lbSize_Click);
            // 
            // rdbLg
            // 
            this.rdbLg.AutoSize = true;
            this.rdbLg.Location = new System.Drawing.Point(195, 65);
            this.rdbLg.Name = "rdbLg";
            this.rdbLg.Size = new System.Drawing.Size(52, 17);
            this.rdbLg.TabIndex = 3;
            this.rdbLg.Text = "Large";
            this.rdbLg.UseVisualStyleBackColor = true;
            this.rdbLg.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbMd
            // 
            this.rdbMd.AutoSize = true;
            this.rdbMd.Location = new System.Drawing.Point(124, 65);
            this.rdbMd.Name = "rdbMd";
            this.rdbMd.Size = new System.Drawing.Size(62, 17);
            this.rdbMd.TabIndex = 2;
            this.rdbMd.Text = "Medium";
            this.rdbMd.UseVisualStyleBackColor = true;
            this.rdbMd.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // rdbSm
            // 
            this.rdbSm.AutoSize = true;
            this.rdbSm.Checked = true;
            this.rdbSm.Location = new System.Drawing.Point(68, 65);
            this.rdbSm.Name = "rdbSm";
            this.rdbSm.Size = new System.Drawing.Size(50, 17);
            this.rdbSm.TabIndex = 1;
            this.rdbSm.TabStop = true;
            this.rdbSm.Text = "Small";
            this.rdbSm.UseVisualStyleBackColor = true;
            this.rdbSm.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // btnAddPizza
            // 
            this.btnAddPizza.Enabled = false;
            this.btnAddPizza.Location = new System.Drawing.Point(537, 411);
            this.btnAddPizza.Name = "btnAddPizza";
            this.btnAddPizza.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btnAddPizza.Size = new System.Drawing.Size(157, 44);
            this.btnAddPizza.TabIndex = 0;
            this.btnAddPizza.Text = "Add Pizza";
            this.btnAddPizza.UseVisualStyleBackColor = true;
            this.btnAddPizza.Click += new System.EventHandler(this.btnAddPizza_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnScrap);
            this.tabPage3.Controls.Add(this.btnTotal);
            this.tabPage3.Controls.Add(this.txtCreditCard);
            this.tabPage3.Controls.Add(this.lbCreditCard);
            this.tabPage3.Controls.Add(this.btnPlaceOrder);
            this.tabPage3.Controls.Add(this.btnRemovePizza);
            this.tabPage3.Controls.Add(this.lstPizzas);
            this.tabPage3.Controls.Add(this.lbReview);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(732, 473);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Review Order";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnScrap
            // 
            this.btnScrap.Enabled = false;
            this.btnScrap.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScrap.Location = new System.Drawing.Point(536, 346);
            this.btnScrap.Name = "btnScrap";
            this.btnScrap.Size = new System.Drawing.Size(179, 79);
            this.btnScrap.TabIndex = 26;
            this.btnScrap.Text = "Scrap Order";
            this.btnScrap.UseVisualStyleBackColor = true;
            this.btnScrap.Click += new System.EventHandler(this.btnScrap_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.Location = new System.Drawing.Point(433, 235);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(235, 79);
            this.btnTotal.TabIndex = 25;
            this.btnTotal.Text = "Order Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // txtCreditCard
            // 
            this.txtCreditCard.Location = new System.Drawing.Point(467, 84);
            this.txtCreditCard.Name = "txtCreditCard";
            this.txtCreditCard.Size = new System.Drawing.Size(175, 20);
            this.txtCreditCard.TabIndex = 24;
            // 
            // lbCreditCard
            // 
            this.lbCreditCard.AutoSize = true;
            this.lbCreditCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCreditCard.Location = new System.Drawing.Point(407, 43);
            this.lbCreditCard.Name = "lbCreditCard";
            this.lbCreditCard.Size = new System.Drawing.Size(289, 24);
            this.lbCreditCard.TabIndex = 22;
            this.lbCreditCard.Text = "Enter the Customer\'s Credit Card:";
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlaceOrder.Location = new System.Drawing.Point(351, 346);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(179, 79);
            this.btnPlaceOrder.TabIndex = 20;
            this.btnPlaceOrder.Text = "Place Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // btnRemovePizza
            // 
            this.btnRemovePizza.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemovePizza.Location = new System.Drawing.Point(433, 133);
            this.btnRemovePizza.Name = "btnRemovePizza";
            this.btnRemovePizza.Size = new System.Drawing.Size(235, 79);
            this.btnRemovePizza.TabIndex = 19;
            this.btnRemovePizza.Text = "Remove Pizza";
            this.btnRemovePizza.UseVisualStyleBackColor = true;
            this.btnRemovePizza.Click += new System.EventHandler(this.btnRemovePizza_Click);
            // 
            // lstPizzas
            // 
            this.lstPizzas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstPizzas.FormattingEnabled = true;
            this.lstPizzas.HorizontalScrollbar = true;
            this.lstPizzas.ItemHeight = 20;
            this.lstPizzas.Location = new System.Drawing.Point(50, 101);
            this.lstPizzas.Name = "lstPizzas";
            this.lstPizzas.Size = new System.Drawing.Size(294, 324);
            this.lstPizzas.TabIndex = 18;
            this.lstPizzas.SelectedIndexChanged += new System.EventHandler(this.lstPizzas_SelectedIndexChanged);
            // 
            // lbReview
            // 
            this.lbReview.AutoSize = true;
            this.lbReview.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReview.Location = new System.Drawing.Point(43, 43);
            this.lbReview.Name = "lbReview";
            this.lbReview.Size = new System.Drawing.Size(301, 37);
            this.lbReview.TabIndex = 17;
            this.lbReview.Text = "Review your Pizzas:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.OrderCancelled);
            this.tabPage2.Controls.Add(this.btnOrderPaid);
            this.tabPage2.Controls.Add(this.lstOrders);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(752, 511);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Orders";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // OrderCancelled
            // 
            this.OrderCancelled.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderCancelled.Location = new System.Drawing.Point(397, 387);
            this.OrderCancelled.Name = "OrderCancelled";
            this.OrderCancelled.Size = new System.Drawing.Size(258, 118);
            this.OrderCancelled.TabIndex = 2;
            this.OrderCancelled.Text = "Order Cancelled";
            this.OrderCancelled.UseVisualStyleBackColor = true;
            this.OrderCancelled.Click += new System.EventHandler(this.OrderCancelled_Click);
            // 
            // btnOrderPaid
            // 
            this.btnOrderPaid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrderPaid.Location = new System.Drawing.Point(104, 387);
            this.btnOrderPaid.Name = "btnOrderPaid";
            this.btnOrderPaid.Size = new System.Drawing.Size(258, 118);
            this.btnOrderPaid.TabIndex = 1;
            this.btnOrderPaid.Text = "Order Paid";
            this.btnOrderPaid.UseVisualStyleBackColor = true;
            this.btnOrderPaid.Click += new System.EventHandler(this.btnOrderPaid_Click);
            // 
            // lstOrders
            // 
            this.lstOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstOrders.FormattingEnabled = true;
            this.lstOrders.HorizontalScrollbar = true;
            this.lstOrders.ItemHeight = 20;
            this.lstOrders.Location = new System.Drawing.Point(6, 13);
            this.lstOrders.Name = "lstOrders";
            this.lstOrders.Size = new System.Drawing.Size(740, 364);
            this.lstOrders.TabIndex = 0;
            this.lstOrders.SelectedIndexChanged += new System.EventHandler(this.listBoxOrders_SelectedIndexChanged);
            // 
            // frmPizzaShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmPizzaShop";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PizzaShop";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.pnlSausage.ResumeLayout(false);
            this.pnlSausage.PerformLayout();
            this.pnlJalapenos.ResumeLayout(false);
            this.pnlJalapenos.PerformLayout();
            this.pnlGreenPeppers.ResumeLayout(false);
            this.pnlGreenPeppers.PerformLayout();
            this.pnlBacon.ResumeLayout(false);
            this.pnlBacon.PerformLayout();
            this.pnlBP.ResumeLayout(false);
            this.pnlBP.PerformLayout();
            this.pnlPepperoni.ResumeLayout(false);
            this.pnlPepperoni.PerformLayout();
            this.pnlPineapple.ResumeLayout(false);
            this.pnlPineapple.PerformLayout();
            this.pnlTomato.ResumeLayout(false);
            this.pnlTomato.PerformLayout();
            this.pnlHam.ResumeLayout(false);
            this.pnlHam.PerformLayout();
            this.pnlMushrooms.ResumeLayout(false);
            this.pnlMushrooms.PerformLayout();
            this.pnlSpinach.ResumeLayout(false);
            this.pnlSpinach.PerformLayout();
            this.pnlOnions.ResumeLayout(false);
            this.pnlOnions.PerformLayout();
            this.pnlBlackOlives.ResumeLayout(false);
            this.pnlBlackOlives.PerformLayout();
            this.pnlGreenOlives.ResumeLayout(false);
            this.pnlGreenOlives.PerformLayout();
            this.pnlAnchovies.ResumeLayout(false);
            this.pnlAnchovies.PerformLayout();
            this.pnlSize.ResumeLayout(false);
            this.pnlSize.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RadioButton rdbLg;
        private System.Windows.Forms.RadioButton rdbMd;
        private System.Windows.Forms.RadioButton rdbSm;
        private System.Windows.Forms.Button btnAddPizza;
        private System.Windows.Forms.Label lbSize;
        private System.Windows.Forms.Label lbToppings;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label lbLoginpage2;
        private System.Windows.Forms.ListBox lstOrders;
        private System.Windows.Forms.Button btnSubmitEmployees;
        private System.Windows.Forms.Panel pnlGreenPeppers;
        private System.Windows.Forms.RadioButton rdbAddGreenPeppers;
        private System.Windows.Forms.RadioButton rdbNoGP;
        private System.Windows.Forms.Label lbGreenPeppers;
        private System.Windows.Forms.Panel pnlSize;
        private System.Windows.Forms.Panel pnlSausage;
        private System.Windows.Forms.RadioButton rdbAddSasuage;
        private System.Windows.Forms.RadioButton rdbNoSausage;
        private System.Windows.Forms.Label lbSausage;
        private System.Windows.Forms.Panel pnlJalapenos;
        private System.Windows.Forms.RadioButton rdbAddJalapenos;
        private System.Windows.Forms.RadioButton rdbNoJalapenos;
        private System.Windows.Forms.Label lbJalapenos;
        private System.Windows.Forms.Panel pnlBacon;
        private System.Windows.Forms.RadioButton rdbAddBacon;
        private System.Windows.Forms.RadioButton rdbNoBacon;
        private System.Windows.Forms.Label lbBacon;
        private System.Windows.Forms.Panel pnlBP;
        private System.Windows.Forms.RadioButton rdbAddBanana;
        private System.Windows.Forms.RadioButton rdbNoBP;
        private System.Windows.Forms.Label lbBananaPeppers;
        private System.Windows.Forms.Panel pnlHam;
        private System.Windows.Forms.RadioButton rdbAddHam;
        private System.Windows.Forms.RadioButton rdbNoHam;
        private System.Windows.Forms.Label lbHam;
        private System.Windows.Forms.Panel pnlTomato;
        private System.Windows.Forms.RadioButton rdbAddTomato;
        private System.Windows.Forms.RadioButton rdbNoTomato;
        private System.Windows.Forms.Label lbTomato;
        private System.Windows.Forms.Panel pnlPineapple;
        private System.Windows.Forms.RadioButton rdbAddPineapple;
        private System.Windows.Forms.RadioButton rdbNoPineapple;
        private System.Windows.Forms.Label lbPineapple;
        private System.Windows.Forms.Panel pnlMushrooms;
        private System.Windows.Forms.RadioButton rdbAddMushrooms;
        private System.Windows.Forms.RadioButton rdbNoMush;
        private System.Windows.Forms.Label lbMushrooms;
        private System.Windows.Forms.Panel pnlPepperoni;
        private System.Windows.Forms.RadioButton rdbAddPepperoni;
        private System.Windows.Forms.RadioButton rdbNopepperoni;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel pnlSpinach;
        private System.Windows.Forms.RadioButton rdbAddSpinach;
        private System.Windows.Forms.RadioButton rdbNoSpinach;
        private System.Windows.Forms.Label lbSpinach;
        private System.Windows.Forms.Panel pnlOnions;
        private System.Windows.Forms.RadioButton rdbAddOnions;
        private System.Windows.Forms.RadioButton rdbNoOnions;
        private System.Windows.Forms.Label lbOnions;
        private System.Windows.Forms.Panel pnlBlackOlives;
        private System.Windows.Forms.RadioButton rdbAddBlackOlives;
        private System.Windows.Forms.RadioButton rdbNoBO;
        private System.Windows.Forms.Label lbBlackOlives;
        private System.Windows.Forms.Panel pnlGreenOlives;
        private System.Windows.Forms.RadioButton rdbAddGreenOlives;
        private System.Windows.Forms.RadioButton rdbNoGO;
        private System.Windows.Forms.Label lbGreenOlives;
        private System.Windows.Forms.Panel pnlAnchovies;
        private System.Windows.Forms.RadioButton rdbAddAnchovies;
        private System.Windows.Forms.RadioButton rdbNoAnchovies;
        private System.Windows.Forms.Label lbAnchovies;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtCreditCard;
        private System.Windows.Forms.Label lbCreditCard;
        private System.Windows.Forms.Button btnPlaceOrder;
        private System.Windows.Forms.Button btnRemovePizza;
        private System.Windows.Forms.ListBox lstPizzas;
        private System.Windows.Forms.Label lbReview;
        private System.Windows.Forms.Button OrderCancelled;
        private System.Windows.Forms.Button btnOrderPaid;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.Label lbID;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.TextBox txtCustomerFName;
        private System.Windows.Forms.Label lbCustomerName;
        private System.Windows.Forms.TextBox txtCusomterLName;
        private System.Windows.Forms.Label lbLName;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Button btnEnterName;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnScrap;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label label1;
    }
}


﻿namespace WindowsFormsApplication1
{


    partial class ds
    {
    }
}
